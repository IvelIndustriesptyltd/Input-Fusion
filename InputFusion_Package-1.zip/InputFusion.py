import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QLabel
from about_dialog import AboutDialog
import subprocess, os

class InputFusion(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("InputFusion")
        self.setGeometry(100, 100, 400, 300)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(QLabel("InputFusion — Input Mapping Hub"))

        buttons = [
            ("Install VJoy Driver", self.install_vjoy),
            ("Install ViGEm Driver", self.install_vigem),
            ("Launch Mapper", self.launch_mapper),
            ("About / License", self.show_about)
        ]
        for label, func in buttons:
            btn = QPushButton(label)
            btn.clicked.connect(func)
            layout.addWidget(btn)

        self.setLayout(layout)

    def install_vjoy(self):
        subprocess.Popen([os.path.join("drivers", "VJoySetup.exe")])

    def install_vigem(self):
        subprocess.Popen([os.path.join("drivers", "ViGEmBusSetup.exe")])

    def launch_mapper(self):
        print("Mapping logic not yet implemented.")

    def show_about(self):
        dialog = AboutDialog()
        dialog.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = InputFusion()
    window.show()
    sys.exit(app.exec_())
