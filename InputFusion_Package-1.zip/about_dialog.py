from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTextEdit, QPushButton

class AboutDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("About InputFusion")
        self.resize(500, 400)

        layout = QVBoxLayout()
        eula_text = """
InputFusion v1.0
Developed by Ivel Industries

--- LICENSE AGREEMENT ---
By using this software, you agree to the following:
1. InputFusion is licensed for personal and commercial use.
2. No warranties are provided. Use at your own risk.
3. Do not use for illegal or unauthorized purposes.
4. This app uses third-party drivers (VJoy, ViGEm) under their own licenses.

For questions: admin@ivelindustries.com.au
"""
        text_area = QTextEdit()
        text_area.setReadOnly(True)
        text_area.setPlainText(eula_text.strip())
        layout.addWidget(text_area)

        close_button = QPushButton("Close")
        close_button.clicked.connect(self.close)
        layout.addWidget(close_button)

        self.setLayout(layout)
